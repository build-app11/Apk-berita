# Beritaku

Aplikasi pembaca berita Android sederhana dengan feed dari Google News (RSS, bahasa Indonesia).

Fitur: kategori berita, pencarian, tarik untuk refresh, mode gelap otomatis, buka artikel di browser.

## Cara build via GitHub (tanpa Android Studio)
1. Buat repository baru di GitHub, lalu upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis saat push, atau klik **Run workflow**).
3. Setelah hijau, buka run tersebut -> bagian **Artifacts** -> unduh `Beritaku-debug-apk`.
4. Ekstrak zip, pindahkan `app-debug.apk` ke HP, lalu install (izinkan "install dari sumber tidak dikenal").
