package com.example.beritaku

import android.text.format.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

data class Article(
    val title: String,
    val source: String,
    val link: String,
    val publishedAt: Long,
) {
    fun timeAgo(): String =
        if (publishedAt <= 0L) "" else
            DateUtils.getRelativeTimeSpanString(
                publishedAt, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
            ).toString()
}

data class Category(val label: String, val topic: String?)

object NewsRepository {

    val categories = listOf(
        Category("Terbaru", null),
        Category("Indonesia", "NATION"),
        Category("Dunia", "WORLD"),
        Category("Bisnis", "BUSINESS"),
        Category("Teknologi", "TECHNOLOGY"),
        Category("Olahraga", "SPORTS"),
        Category("Hiburan", "ENTERTAINMENT"),
        Category("Sains", "SCIENCE"),
        Category("Kesehatan", "HEALTH"),
    )

    private const val LOCALE = "hl=id&gl=ID&ceid=ID:id"

    fun feedUrl(category: Category): String =
        if (category.topic == null) "https://news.google.com/rss?$LOCALE"
        else "https://news.google.com/rss/headlines/section/topic/${category.topic}?$LOCALE"

    fun searchUrl(query: String): String =
        "https://news.google.com/rss/search?q=${URLEncoder.encode(query, "UTF-8")}&$LOCALE"

    suspend fun fetch(url: String): List<Article> = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 15_000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) Beritaku/1.0")
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            conn.inputStream.use { parse(it) }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(input: InputStream): List<Article> {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(input, null)
        val dateFormat = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.ENGLISH)

        val result = mutableListOf<Article>()
        var inItem = false
        var tag = ""
        var title = StringBuilder()
        var link = StringBuilder()
        var date = StringBuilder()
        var source = StringBuilder()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    tag = parser.name
                    if (tag == "item") {
                        inItem = true
                        title = StringBuilder(); link = StringBuilder()
                        date = StringBuilder(); source = StringBuilder()
                    }
                }
                XmlPullParser.TEXT -> if (inItem) {
                    when (tag) {
                        "title" -> title.append(parser.text)
                        "link" -> link.append(parser.text)
                        "pubDate" -> date.append(parser.text)
                        "source" -> source.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "item") {
                        inItem = false
                        val src = source.toString().trim()
                        var t = title.toString().trim()
                        if (src.isNotEmpty() && t.endsWith(" - $src")) {
                            t = t.removeSuffix(" - $src")
                        }
                        val time = try {
                            dateFormat.parse(date.toString().trim())?.time ?: 0L
                        } catch (e: Exception) {
                            0L
                        }
                        if (t.isNotEmpty() && link.isNotBlank()) {
                            result.add(Article(t, src, link.toString().trim(), time))
                        }
                    }
                    tag = ""
                }
            }
            event = parser.next()
        }
        return result
    }
}
